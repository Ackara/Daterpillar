﻿DROP DATABASE IF EXISTS `dtpl_deleteMe`;
