﻿CREATE INDEX `card_Level` ON `card` (`Level` DESC);
