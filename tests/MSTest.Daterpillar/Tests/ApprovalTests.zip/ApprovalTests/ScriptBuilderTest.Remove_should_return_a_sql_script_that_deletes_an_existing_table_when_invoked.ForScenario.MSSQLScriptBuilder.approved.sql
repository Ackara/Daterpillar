﻿DROP TABLE [ability];
