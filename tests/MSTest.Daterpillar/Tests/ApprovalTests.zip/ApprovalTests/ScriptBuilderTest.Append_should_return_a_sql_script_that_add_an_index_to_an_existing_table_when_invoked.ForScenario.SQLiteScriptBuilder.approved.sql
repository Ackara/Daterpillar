﻿CREATE INDEX IF NOT EXISTS [card_Level] ON [card] ([Level] DESC);
