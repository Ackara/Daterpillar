﻿ALTER TABLE [card_number] DROP CONSTRAINT [key_with_custom_name];
