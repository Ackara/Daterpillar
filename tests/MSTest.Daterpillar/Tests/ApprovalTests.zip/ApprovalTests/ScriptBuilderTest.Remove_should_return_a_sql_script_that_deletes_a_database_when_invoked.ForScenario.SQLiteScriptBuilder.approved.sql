/* SQLite do not support DROP DATABASE */
