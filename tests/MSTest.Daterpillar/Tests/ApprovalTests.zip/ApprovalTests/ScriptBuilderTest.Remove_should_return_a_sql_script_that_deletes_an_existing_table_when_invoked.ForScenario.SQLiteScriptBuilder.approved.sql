﻿DROP TABLE IF EXISTS [ability];
