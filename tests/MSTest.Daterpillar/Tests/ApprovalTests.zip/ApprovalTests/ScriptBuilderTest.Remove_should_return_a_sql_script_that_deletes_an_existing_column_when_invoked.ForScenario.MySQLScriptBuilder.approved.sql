﻿ALTER TABLE `card_extras` DROP COLUMN `Trivia`;
