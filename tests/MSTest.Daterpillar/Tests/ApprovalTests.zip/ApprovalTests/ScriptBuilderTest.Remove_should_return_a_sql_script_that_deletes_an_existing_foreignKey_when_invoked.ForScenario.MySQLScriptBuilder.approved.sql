﻿ALTER TABLE `card_number` DROP FOREIGN KEY `key_with_custom_name`;
